Parts from earlier attempts to write a generic PHP lib
by Dennis Kehrig
http://www.denniskehrig.de/